/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tvstreamingapp;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Kaone
 */
public class Series {
//Declaration
    private static ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    //Menu option 1-Capture Series
    public void captureSeries() {
        System.out.println("\nCAPTURE NEW SERIES");
        System.out.println("**********************************");

        System.out.print("Enter Series id: ");
        String seriesId = scanner.nextLine();

        System.out.print("Enter series name: ");
        String seriesName = scanner.nextLine();

        String seriesAge;

        //Validate age restriction
        while (true) {
            System.out.print("Enter the series age restriction:");
            String ageInput = scanner.nextLine();

            try {
                int age = Integer.parseInt(ageInput);
                if (age >= 2 && age <= 18) {
                    seriesAge = ageInput;
                    break;
                } else {
                    System.out.println("You have entered an incorrect series age!!!");
                    System.out.print("Please re-enter the series age >> ");
                }
            } catch (NumberFormatException e) {
                System.out.println("You e entered an incorrect series age!!!");
                System.out.print("Please re-enter the series age >> ");
            }
        }

        //ask user for number od episodes
        System.out.print("Enter the number of episodes of " + seriesName + ":");
        String seriesEpisodes = scanner.nextLine();

        SeriesModel newSeries = new SeriesModel(seriesId, seriesName, seriesAge, seriesEpisodes);
        seriesList.add(newSeries);

        System.out.println("Series processed sucessfully!!!");
    }

    //Menu option 2- Search Series
    public void searchSeries() {
        System.out.print("Enter the series id to search: ");
        String searchId = scanner.nextLine();

        SeriesModel foundSeries = findSeriesById(searchId);

        if (foundSeries != null) {
            System.out.println("------------------------");
            displaySeriesDetails(foundSeries);
            System.out.println("--------------------------");
        } else {
            System.out.println("--------------------------");
            System.out.println("Series with Series Id: " + searchId + " was not found!");
            System.out.println("--------------------------");
        }
    }

    //Menu option 3- Update Series
    public void updateSeries() {
        System.out.print("Enter the series id to update: ");
        String searchId = scanner.nextLine();

        SeriesModel seriesToUpdate = findSeriesById(searchId);

        if (seriesToUpdate != null) {
            //ask user for new information
            System.out.print("Enter the series name: ");
            String newName = scanner.nextLine();

            //Get new age restriction with validation 
            String newAge;
            while (true) {
                System.out.print("Enter the series age restriction (2-18): ");
                String ageInput = scanner.nextLine();
                try {
                    int age = Integer.parseInt(ageInput);
                    if (age >= 2 && age <= 18) {
                        newAge = ageInput;
                        break;
                    } else {
                        System.out.println("You have entered an incorrect series age!!!");
                    }
                } catch (NumberFormatException e) {
                    System.out.print("Please re-enter the series age between 2-18 ");
                }
            }
            //ask user for new number of episodes
            System.out.print("Enter the number of episodes:");
            String newEpisodes = scanner.nextLine();

            seriesToUpdate.seriesName = newName;
            seriesToUpdate.seriesAge = newAge;
            seriesToUpdate.seriesNumberOfEpisodes = newEpisodes;

            System.out.println("Series updated successfully!");
        } else {
            System.out.println("Series with Series Id: " + searchId + " was not found!");
        }
        System.out.print("Enter (1) to launch menu or any other key to exit");
        String option = scanner.nextLine();
        if (!option.equals("1")) {
            System.exit(0);
        }
    }
    
//Menu option 4-Delete Series
    public void deleteSeries() {
        //ask user for the series id needed to be deleted
        System.out.print("\nEnter the series id to delete: ");
        String searchId = scanner.nextLine();
        
        // Find the series to delete
        SeriesModel seriesToDelete = findSeriesById(searchId);

        if (seriesToDelete != null) {
            System.out.print("Are you sure you want to delete series" + searchId + "from the system? Yes (y) to delete: ");
            String confirm = scanner.nextLine();

            if (confirm.equalsIgnoreCase("y")) {
                seriesList.remove(seriesToDelete);
                System.out.println("--------------------------------------");
                System.out.println("Series with Series Id: " + searchId + " WAS deleted!");
                System.out.println("--------------------------------------");
            } else {
                System.out.println("Deletion cancelled");
            }
        } else {
            System.out.println("--------------------------------------");
            System.out.println("Series with Series Id: " + searchId + " was not found!");
            System.out.println("--------------------------------------");
        }
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String option = scanner.nextLine();
        if (!option.equals("1")) {
            System.exit(0);
        }
    }

    //Menu option 5- Series Report
    public void seriesReport() {
        System.out.println("\nSERIES REPORT");

        if (seriesList.isEmpty()) {
            System.out.println("No series found in the system");
        } else {
            for (int i = 0; i < seriesList.size(); i++) {
                System.out.println("\nSeries " + (i + 1));
                System.out.println("--------------------");
                displaySeriesDetails(seriesList.get(i));
                System.out.println("---------------------");
            }
        }
    }

    public void exitSeriesApplication() {
        System.out.println("Thank you for using the TV Series Management Application");
        System.exit(0);
    }
    
    public ArrayList<SeriesModel>getSeriesList(){
        return seriesList;
    }

    public SeriesModel findSeriesById(String seriesId) {
        for (SeriesModel series : seriesList) {
            if (series.seriesId.equals(seriesId)) {
                return series;
            }
        }
        return null;
    }

    private void displaySeriesDetails(SeriesModel series) {
        System.out.println(series.toString());
    }
}
