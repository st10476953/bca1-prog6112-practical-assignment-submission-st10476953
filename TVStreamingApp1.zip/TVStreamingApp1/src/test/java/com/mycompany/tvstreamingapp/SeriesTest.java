/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.tvstreamingapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Kaone
 */
public class SeriesTest {

    public SeriesTest() {
    }

    @Test
    public void testSearchSeries() {
        //Arrange
        Series seriesManager = new Series();
        seriesManager.getSeriesList().add(new SeriesModel("101", "Extreme Sports", "12", "10"));

        //Act
        SeriesModel result = seriesManager.findSeriesById("101");

        //Assert
        assertNotNull(result);
        assertEquals("Extreme Sports", result.seriesName);
        assertEquals("12", result.seriesAge);
    }

    @Test
    public void testSearchSeries_SeriesNotFound() {
        //Arrange
        Series seriesManager = new Series();
        seriesManager.getSeriesList().add(new SeriesModel("101", "Extreme Sports", "12", "10"));

        //Act
        SeriesModel result = seriesManager.findSeriesById("999");

        //Assert
        assertNull(result);
    }

    @Test
    public void testUpdateSeries() {
        //Arrange
        Series seriesManager = new Series();
        seriesManager.getSeriesList().add(new SeriesModel("101", "Extreme Sports", "12", "10"));

        SeriesModel result = seriesManager.findSeriesById("999");
        assertNull(result);

        //Act
        result.seriesName = "Extreme Sports 2025";
        result.seriesAge = "15";
        result.seriesNumberOfEpisodes = "12";

        //Assert"
        assertEquals("Extreme Sports 2025", result.seriesName);
        assertEquals("12", result.seriesAge);
        assertEquals("12", result.seriesNumberOfEpisodes);
    }

    @Test
    public void testDeleteSeries() {
        //Arrange
        Series seriesManager = new Series();
        seriesManager.getSeriesList().add(new SeriesModel("101", "Extreme Sports", "12", "10"));

        SeriesModel result = seriesManager.findSeriesById("101");
        assertNotNull(result);

        //Act
        seriesManager.getSeriesList().remove(result);

        //Assert
        assertNull(seriesManager.findSeriesById("101"));
        assertEquals(0, seriesManager.getSeriesList().size());
    }

    @Test
    public void testDeleteSeries_SeriesNotFound() {
        //Arrange
        Series seriesManager = new Series();
        seriesManager.getSeriesList().add(new SeriesModel("101", "Extreme Sports", "12", "10"));

        //Act
        SeriesModel result = seriesManager.findSeriesById("999");

        //Assert
        assertNull(result);
        assertEquals(1, seriesManager.getSeriesList().size());
    }

    @Test
    public void testSeriesAgeRestriction_AgeValid() {
        //Arrange
        int validAge = 15;

        //Act & Assert
        assertTrue(validAge >= 2 && validAge <= 18);
    }

    @Test
    public void testSeriesAgeRestriction_AgeInValid() {
        //Arrange
        int invalidAge = 25;

        //Act & Assert
        assertFalse(invalidAge >= 2 && invalidAge <= 18);
    }
}
