/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.quizgame;

import java.util.Scanner;

/**
 *
 * @author Kaone
 */
public class QuizGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        QuizQuestions[] questions = new QuizQuestions[6];

        questions[0] = new FillInQ(
                "What programming language runs on the JVM and is strongly typed?",//question
                "Programming",//category
                10,//score points
                "Java",//correct answer
                "Popular with Android and enterprise"//hint
        );

        questions[1] = new TrueOrFalseQ(
                "The Earth is flat.",//question
                "Science",//category
                5,//score ponts
                false,// correct answer
                "Scientific consensus shows Earth is an oblate spheroid."//hint
        );

        questions[2] = new MultipleChoiceQ(
                "Which number is prime? (enter option number)",//question
                "Math",//category
                10,//score point
                new String[]{"9", "12", "13", "21"},//options
                3// 1-based index from user, 3 means option "13" is the answer
        );

        questions[3] = new FillInQ(
                "Fill in the chemical symbol for water.",//question
                "Science",//category
                10,//score point
                "H2O",//answer
                "Two hydrogen, one oxygen"//hint
        );

        questions[4] = new TrueOrFalseQ(
                "Light travels faster than sound.",//question
                "Science",//catergory
                5, //score point
                true,//Correct answer
                "c (~3e8 m/s) is greater than speed of sound (~343 m/s)."//hint
        );

        questions[5] = new MultipleChoiceQ(
                "Select the largest planet in our solar system (enter option number)",//question
                "Astronomy",//catgeory
                10,//score points
                new String[]{"Earth", "Venus", "Jupiter", "Mars"},//option
                3 // option 3 → Jupiter is the answer
        );

        int totalScore = 0;
        int totalPossible = 0;

        questions[1].setScorePoints(questions[1].getScorePoints() + 5);

        for (int i = 0; i < questions.length; i++) {
            QuizQuestions q = questions[i];
            totalPossible += q.getScorePoints();

            System.out.println("\nQuestion " + (i + 1) + " [" + q.getCategory() + "] (" + q.getScorePoints() + " pts):");
            System.out.println(q.getQuestionText());

            if (q instanceof MultipleChoiceQ) {
                MultipleChoiceQ mcq = (MultipleChoiceQ) q;
                String[] opts = mcq.getOptions();
                for (int j = 0; j < opts.length; j++) {
                    System.out.println((j + 1) + ") " + opts[j]);
                }
            }

            // Provides a hint for FillInQ questions
            if (q instanceof FillInQ) {
                FillInQ fi = (FillInQ) q;
                System.out.println("(Hint): " + fi.getHint());
            }

            System.out.print("Your answer: ");
            String userAnswer = scanner.nextLine();

            //Check answer
            if (q.checkAnswer(userAnswer)) {
                totalScore += q.getScorePoints();
                System.out.println("Correct! +" + q.getScorePoints() + " points.");
            } else {
                System.out.println("Incorrect.");
            }
        }
        // Console report 
        System.out.println("\n================ QUIZ REPORT ================");
        System.out.println("Total Score: " + totalScore + " / " + totalPossible);

        String[] categories = new String[questions.length];
        int[] earned = new int[questions.length];
        int[] possible = new int[questions.length];
        int uniqueCount = 0;

        for (int i = 0; i < questions.length; i++) {
            QuizQuestions q = questions[i];
            String cat = q.getCategory();

            // find category index
            int idx = -1;
            for (int c = 0; c < uniqueCount; c++) {
                if (categories[c].equals(cat)) {
                    idx = c;
                    break;
                }
            }
            if (idx == -1) {
                idx = uniqueCount;
                categories[uniqueCount] = cat;
                earned[uniqueCount] = 0;
                possible[uniqueCount] = 0;
                uniqueCount++;
            }

            //Add points
            possible[idx] += q.getScorePoints();
            if (q.isAnsweredCorrectly()) {
                earned[idx] += q.getScorePoints();
            }
        }

        System.out.println("Category Breakdown:");
        for (int i = 0; i < uniqueCount; i++) {
            System.out.println("- " + categories[i] + ": " + earned[i] + " / " + possible[i]);
        }

        System.out.println("============================================");

        scanner.close();
    }
}
