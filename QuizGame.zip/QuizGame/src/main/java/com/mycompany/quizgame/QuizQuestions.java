/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizgame;

/**
 *
 * @author Kaone
 */
public abstract class QuizQuestions {

    //Parent class
    private String questionText;
    private String category;
    private int scorePoints;
    private boolean answeredCorrectly;  //tracks if the question was answered correctly

    //Constructors
    public QuizQuestions() {
    }

    public QuizQuestions(String questionText, String category, int scorePoints) {
        this.questionText = questionText;
        this.category = category;
        this.scorePoints = scorePoints;
        this.answeredCorrectly = false;
    }

    //Setters and Getters
    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getScorePoints() {
        return scorePoints;
    }

    public void setScorePoints(int scorePoints) {
        this.scorePoints = scorePoints;
    }

    public boolean isAnsweredCorrectly() {
        return answeredCorrectly;
    }

    protected void setAnsweredCorrectly(boolean answeredCorrectly) {
        this.answeredCorrectly = answeredCorrectly;
    }

    public abstract boolean checkAnswer(String userAnswer);

    protected String normalize(String value) {
        if (value == null) {
            return "";
        }
        return value.trim().toLowerCase();
    }

}

