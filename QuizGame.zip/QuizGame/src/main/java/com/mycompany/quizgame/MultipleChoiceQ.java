/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizgame;

/**
 *
 * @author Kaone
 */
public class MultipleChoiceQ extends QuizQuestions {
//Child Class

    private String[] options;
    private int correctIndex;   //checks which option is correct (index starts at 0)

    public MultipleChoiceQ() {
        super();//calls the parent class
        this.options = new String[0];
        this.correctIndex = -1;
    }

//Constructors with parameters
    public MultipleChoiceQ(String questionText, String category, int points,
            String[] options, int correctIndex) {
        super(questionText, category, points);

        this.options = (options == null) ? new String[0] : options;

        // Validate correct index
        if (correctIndex < 0 || correctIndex >= this.options.length) {
        } else {
            System.out.println("Invalid Index");

        }
        this.correctIndex = correctIndex;
    }

    //Setters and Getters
    public String[] getOptions() {
        return options;
    }

    public void setOptions(String[] options) {
        this.options = options;
    }

    public int getCorrectIndex() {
        return correctIndex;
    }

    public void setCorrectIndex(int correctIndex) {
        this.correctIndex = correctIndex;
        
        //makes sure the value is valid
        if (correctIndex < 0 || correctIndex >= options.length) {
        } else {
            System.out.println("Invalid Index");
        }
    }

    @Override
    public boolean checkAnswer(String userAnswer) {
        try {
            // Converts the user's answer to an integer (1-based input)
            int chosen = Integer.parseInt(userAnswer.trim());

            // Checks if it matches the correct index
            boolean correctNow = (chosen - 1 == correctIndex);

            setAnsweredCorrectly(correctNow);
            return correctNow;

        } catch (NumberFormatException e) {
            // If user enters something invalid
            setAnsweredCorrectly(false);
            return false;
        }
    }
}
