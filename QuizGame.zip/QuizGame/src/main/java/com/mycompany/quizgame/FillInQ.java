/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizgame;

/**
 *
 * @author Kaone
 */
public class FillInQ extends QuizQuestions {
//Child Class

    private String correctAnswer;
    private String hint;

    public FillInQ() {
        super();
    }

//Constructor
    public FillInQ(String questionText, String category, int points, String correctAnswer, String hint) {
        super(questionText, category, points);
        this.correctAnswer = correctAnswer;
        this.hint = hint;
    }

    //setters and getters
    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    @Override
    public boolean checkAnswer(String userAnswer) {
        setAnsweredCorrectly(normalize(userAnswer).equals(normalize(correctAnswer)));
        return isAnsweredCorrectly();
    }

}