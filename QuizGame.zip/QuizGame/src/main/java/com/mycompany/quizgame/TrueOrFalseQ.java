/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizgame;

/**
 *
 * @author Kaone
 */
public class TrueOrFalseQ extends QuizQuestions {
//Child Class

    private boolean correct;
    private String justify;   //Justifies the answer

    public TrueOrFalseQ() {
        super();
    }

    //Constructor
    public TrueOrFalseQ(String questionText, String category, int scorePoints, boolean correct, String justify) {
        super(questionText, category, scorePoints);
        this.correct = correct;
        this.justify = justify;
    }

    //setters and getters
    public boolean isCorrect() {
        return correct;
    }

    public void setCorrect(boolean correct) {
        this.correct = correct;
    }

    public String getJustify() {
        return justify;
    }

    public void setJustify(String justify) {
        this.justify = justify;
    }

    @Override
    public boolean checkAnswer(String userAnswer) {
        boolean correctNow = correct == (normalize(userAnswer).equals("true") || normalize(userAnswer).equals("t"));
        setAnsweredCorrectly(correctNow);
        return correctNow;
    }

}

