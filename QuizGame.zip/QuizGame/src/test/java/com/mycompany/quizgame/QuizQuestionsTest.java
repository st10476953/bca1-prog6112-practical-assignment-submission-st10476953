/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.quizgame;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Kaone
 */
public class QuizQuestionsTest {

    public QuizQuestionsTest() {
    }

    @Test
    public void testFillInQAnswer() {
        // Arrange
        FillInQ fillQ = new FillInQ("Capital of France?", "Geography", 10, "Paris", "City of lights");

        // Act & Assert
        assertTrue(fillQ.checkAnswer("Paris"), "Answer 'Paris' should be correct");
        assertFalse(fillQ.checkAnswer("London"), "Answer 'London' should be incorrect");
        assertTrue(fillQ.checkAnswer("  Paris  "), "Answer with spaces should be correct");
        assertTrue(fillQ.checkAnswer("pARis"), "Answer with different case should be correct");
    }

    @Test
    public void testTrueOrFalseQAnswer() {
        // Arrange
        TrueOrFalseQ tf = new TrueOrFalseQ("The sky is blue?", "Science", 5, true, "Observation");

        // Act & Assert
        assertTrue(tf.checkAnswer("true"), "Answer 'true' should be correct");
        assertTrue(tf.checkAnswer("yes"), "Answer 'yes' should be correct");
        assertTrue(tf.checkAnswer("y"), "Answer 'y' should be correct");
        assertFalse(tf.checkAnswer("false"), "Answer 'false' should be incorrect");
        assertFalse(tf.checkAnswer("no"), "Answer 'no' should be incorrect");
    }

    @Test
    public void testMultipleChoiceQAnswer() {
        // Arrange
        String[] options = {"9", "12", "13", "21"};
        MultipleChoiceQ mcq = new MultipleChoiceQ("Which number is prime?", "Math", 10, options, 2);

        // Act & Assert
        assertTrue(mcq.checkAnswer("3"), "Answer '3' should be correct");   // correctIndex = 2
        assertFalse(mcq.checkAnswer("1"), "Answer '1' should be incorrect");
        assertFalse(mcq.checkAnswer("abc"), "Invalid input should be incorrect");
    }

    @Test
    public void testPolymorphismCheckAnswer() {
        // Arrange
        QuizQuestions[] questions = {
            new FillInQ("Q1", "Cat1", 5, "A1", "Hint1"),
            new TrueOrFalseQ("Q2", "Cat2", 10, true, "Hint2"),
            new MultipleChoiceQ("Q3", "Cat3", 15, new String[]{"O1", "O2"}, 1)
        };
        String[] answers = {"A1", "true", "2"};

        // Act & Assert
        for (int i = 0; i < questions.length; i++) {
            assertTrue(questions[i].checkAnswer(answers[i]), "Question " + (i + 1) + " should be correct");
            assertTrue(questions[i].isAnsweredCorrectly(), "answeredCorrectly should be true for question " + (i + 1));
        }
    }
}

